import "./App.css";
import Hookcontext from "./HookContext";
import Hookref from "./Hookref";

function App() {
  return (
    <>
      <Hookcontext />
      <Hookref />
    </>
  );
}

export default App;
